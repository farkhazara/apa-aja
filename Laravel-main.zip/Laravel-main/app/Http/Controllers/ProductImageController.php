<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProductImageController extends Controller
{
    public function destroy($imageId)
    {
        dd($imageId);
    }
}
