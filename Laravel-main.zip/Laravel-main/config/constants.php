<?php
return [
    'db' => [
        'roles' => [
            'admin' => 'Admin',
            'customer' => 'Customer'
        ],
        'order_status' => [
            'in_process' => 'In_process',
            'paid' => 'Paid',
            'completed' => 'Completed',
        ]
    ]
];
