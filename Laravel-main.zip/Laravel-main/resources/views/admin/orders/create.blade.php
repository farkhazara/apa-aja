@extends('layouts.app')
@section('content')
<p>Create Orders</p>
@endsection