@extends('layouts.app')
@section('title') Admin @endsection
@section('content')
<div class="container center">
    <h1 style="text-align: center">Admin Dashboard:</h1>
</div>
@endsection