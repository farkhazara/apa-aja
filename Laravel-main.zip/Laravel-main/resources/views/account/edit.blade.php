<h1>DELETE</h1>
@extends('layouts.app')

@section('content')
<h1>EDIT</h1>

@endsection