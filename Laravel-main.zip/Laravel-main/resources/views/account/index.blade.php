<h1>DELETE</h1>
@extends('layouts.app')

@section('content')
<h1>INDEX</h1>

@endsection