<a href="{{ route('categories.show', $category->id) }}" class="text-muted btn btn-outline-dark">
    {{__($category->name)}}
</a>